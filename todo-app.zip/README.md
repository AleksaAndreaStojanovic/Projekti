# Todo App

Angular app to track user tasks

### Install Dependencies

```
npm install
```

### Run

```
npm run dev
```