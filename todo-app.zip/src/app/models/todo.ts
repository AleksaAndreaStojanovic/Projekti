export interface Todo {
  id?: number;
  userId?: number;
  title?: string;
  priority?: number;
  completed?: boolean;
}
