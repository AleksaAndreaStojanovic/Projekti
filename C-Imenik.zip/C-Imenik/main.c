#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct osoba{

    char ime[35];
    char adresa[50];
    char tekst[50];
    char br_mobilni[35];
    char br_kuca[35];
    //long int br_mobilni; //string
    //long int br_kuca;
    char e_mail[100];

};
void pocetnaStrana();
void upisi();
void dodajKontakt();
void spisakKontakta();
void izmeniKontakt();
void obrisiKontakt();
void pretraziKontakt();
int main(){

    pocetnaStrana();
    return 0;
}

void pocetnaStrana(){

    system("cls");
    printf("\t*** Mini telefonski imenik ***");
    printf("\n\n\t  Unesite broj opcije (1-6)\n\n");

   // printf("\n\t\t   OPCIJE \t\n");
    printf("\t1.Dodaj\t\t2.Kontakti\n   \t3.Pretrazi\t4.Izmeni\n   \t5.Obrisi\t6.Exit");
    switch(getch()){

    case '1':

        dodajKontakt();
        break;
    case '2':
        spisakKontakta();
        break;
    case '3':
        pretraziKontakt();
        break;
    case '4':
        izmeniKontakt();
        break;
    case '5':
        obrisiKontakt();
        break;
    case '6':
        exit(1);
        break;
    default:
        //system("cls");
        printf("\nUnesite broj opcije (1-6)");
        printf("\nPritisnite bilo koje dugme za povratak na opcije!");
        getch();
        pocetnaStrana();
    }
}
void dodajKontakt(){

    system("cls");
    FILE *f;
    struct osoba o;
    f=fopen("project.txt","ab+");
    printf("\nUnesite ime: ");
    upisi(o.ime);  //f
    printf("\nUnesite adresu: ");
    upisi(o.adresa);
    printf("\nUnesite tekst: ");
    upisi(o.tekst);
    printf("\nUnesite broj mobilnog telefona:");
    upisi(o.br_mobilni);
    //scanf("%ld",&o.br_mobilni);
    printf("\nUnesite broj kucnog telefona:");
    upisi(o.br_kuca);
   // scanf("%ld",&o.br_kuca);
    printf("\nUnesite e-mail:");
    upisi(o.e_mail);
    fwrite(&o,sizeof(o),1,f);
    fflush(stdin);
    printf("\nUspesno sacuvano");
    fclose(f);
    printf("\nPritisnite bilo koje dugme za povratak na opcije!");
    getch();
    system("cls");
    pocetnaStrana();
}
void spisakKontakta(){

    struct osoba o;
    FILE *f;
    f=fopen("project.txt","rb");

    if(f==NULL){
        printf("\nGreska prilikom ucitavanja fajla :");
        exit(1);
    }

    while(fread(&o,sizeof(o),1,f)==1){

        printf("\nKontakt:\n ");
        printf("\nIme=%s\nAdresa=%s\nTekst=%s\nBroj mobilnog telefona=%s\nBroj kucnog telefona=%s\nE-mail=%s"
               ,o.ime,o.adresa,o.tekst,o.br_mobilni,o.br_kuca,o.e_mail);

        //getch(); //
    //system("cls");
    }
    fclose(f);
    printf("\nPritisnite bilo koje dugme za povratak na opcije!");
    getch();
    system("cls");
    pocetnaStrana();
}
void pretraziKontakt(){

    struct osoba o;
    FILE *f;
    char ime[100];
    f=fopen("project.txt","rb");

    if(f==NULL){

        printf("\n GRESKA PRILIKOM OTVARANJA FAJLA\a\a\a\a");
        exit(1);

    }
    printf("\n\n\tUNESITE IME OSOBE ZA PRETRAGU :");
    upisi(ime);

    while(fread(&o,sizeof(o),1,f)==1){

        if(strcmp(o.ime,ime)==0){

            printf("\n\tPodaci o osobi %s",ime);
            printf("\nIme=%s\nAdresa=%s\nTekst=%s\nBroj mobilnog telefona=%ld\nBroj kucnog telefona=%ld\nE-mail=%s",o.ime,o.adresa,o.tekst,o.br_mobilni,o.br_kuca,o.e_mail);
        }
    }
        if(strcmp(o.ime,ime)!=0){
            printf("nije pronadjen fajl");

        }
    fclose(f);
    printf("\nPritisnite bilo koje dugme za povratak na opcije!");
    getch();
    system("cls");
    pocetnaStrana();
}

void obrisiKontakt(){

    struct osoba o;
    FILE *f,*ft;
    int flag;
    char ime[100];
    f=fopen("project.txt","rb");

    if(f==NULL){
        printf("\nNEMA PODATAKA ZA OSOBU");

    }
    else{
        ft=fopen("temp.txt","wb+");

        if(ft==NULL)
            printf("GRESKA PRILIKOM OTVARANJA FAJLA");

        else{
            printf("\n\n\tUNESITE IME OSOBE:");
            upisi(ime);
            fflush(stdin);

            while(fread(&o,sizeof(o),1,f) == 1){

                if(strcmp(o.ime,ime)!=0 )
                    fwrite(&o,sizeof(o),1,ft);
                if(strcmp(o.ime,ime) ==0 )
                    flag=1;
            }
            fclose(f);
            fclose(ft);

            if(flag!=1){
                printf("\nNEMA OSOBA SA TIM IMENOM.");
                remove("temp.txt");
            }
            else{
                remove("project.txt");
                rename("temp.txt","project.txt");
                printf("\nUSPESNO OBRISANO!");
            }
        }
    }
    printf("\nPritisnite bilo koje dugme za povratak na opcije!");
    getch();
    system("cls");
    pocetnaStrana();
}

void izmeniKontakt(){

    int c;
    FILE *f;
    int flag=0;
    struct osoba o,s;
    char  ime[50];
    f=fopen("project.txt","rb+");

    if(f==NULL){
        printf("NEMA PODATAKA JOS ZA TU OSOBU.");
        exit(1);
    }
    else{
        system("cls");
        printf("\nUNESITE IME OSOBE KOJU ZELITE DA IZMENITE:\n");
        upisi(ime);

        while(fread(&o,sizeof(o),1,f)==1){

            if(strcmp(ime,o.ime)==0){

                printf("\n Unesi ime:");
                upisi(s.ime);
                printf("\nUnesi adresu:");
                upisi(s.adresa);
                printf("\nUnesi text:");
                upisi(s.tekst);
                printf("\nUnesi broj mobilnog telefona:");
                upisi(o.br_mobilni);
               //scanf("%ld",&s.br_mobilni);
                printf("\nUnesi broj kucnog telefona:");
                upisi(o.br_kuca);
                //scanf("%ld",&s.br_kuca);
                printf("\nUnesi e-mail:");
                upisi(s.e_mail);
                fseek(f,-sizeof(o),SEEK_CUR); //da stane na kraj _cur- staje ispred podatka da bi ga prekucao.
                fwrite(&s,sizeof(o),1,f);
                flag=1;
                break;

            }

            fflush(stdin);
        }

        if(flag==1){
            printf("\n Imenili ste kontakt");
        }
        else{
            printf(" \n NEMA PODATAKA");
        }
        fclose(f);
    }
    printf("\nPritisnite bilo koje dugme za povratak na opcije!");
    getch();
    system("cls");
    pocetnaStrana();
}
void upisi(char *ime){   //
    int i=0,j;
    char c,ch;
    do{
        c=getch();
        if(c!=8&&c!=13){

          *(ime+i)=c;  //
            putch(c);
            i++;
        }
    }
    while(c!=13);
    *(ime+i)='\0';
}
